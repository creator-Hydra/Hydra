HYDRA - proyecto Android nativo

Este proyecto está preparado para compilarse como APK usando Gradle.
No es la PWA anterior.

Funciones:
- Registro de agua
- Meta diaria configurable
- Horario de inicio y fin
- Intervalo configurable
- Notificaciones de Android
- Reprogramación después de reiniciar el teléfono
- Usa alarmas exactas si Android permite el permiso; si no, usa alarmas que pueden retrasarse un poco.
- El valor inicial de 2000 ml es solo un valor de ejemplo configurable, no una recomendación médica universal.

Para compilar:
gradle :app:assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
