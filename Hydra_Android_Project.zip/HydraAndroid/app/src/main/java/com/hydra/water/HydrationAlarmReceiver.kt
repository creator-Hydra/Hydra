package com.hydra.water

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class HydrationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        NotificationHelper.createChannel(context)
        NotificationHelper.show(context)
        ReminderScheduler.scheduleNext(context)
    }
}
