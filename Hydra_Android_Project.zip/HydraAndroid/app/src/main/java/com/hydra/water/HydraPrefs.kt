package com.hydra.water

import android.content.Context
import java.time.LocalDate

object HydraPrefs {
    private const val PREF = "hydra"
    private const val GOAL = "goal"
    private const val START = "start"
    private const val END = "end"
    private const val INTERVAL = "interval"
    private const val AMOUNT = "amount"
    private const val DATE = "date"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun goal(c: Context) = p(c).getInt(GOAL, 2000)
    fun start(c: Context) = p(c).getInt(START, 8 * 60)
    fun end(c: Context) = p(c).getInt(END, 22 * 60)
    fun interval(c: Context) = p(c).getInt(INTERVAL, 120)

    fun saveSettings(c: Context, goal: Int, start: Int, end: Int, interval: Int) {
        p(c).edit().putInt(GOAL, goal).putInt(START, start).putInt(END, end)
            .putInt(INTERVAL, interval).apply()
    }

    fun amount(c: Context): Int {
        ensureToday(c)
        return p(c).getInt(AMOUNT, 0)
    }

    fun add(c: Context, ml: Int) {
        ensureToday(c)
        p(c).edit().putInt(AMOUNT, amount(c) + ml).apply()
    }

    fun reset(c: Context) {
        p(c).edit().putString(DATE, LocalDate.now().toString()).putInt(AMOUNT, 0).apply()
    }

    private fun ensureToday(c: Context) {
        val today = LocalDate.now().toString()
        val stored = p(c).getString(DATE, null)
        if (stored != today) {
            p(c).edit().putString(DATE, today).putInt(AMOUNT, 0).apply()
        }
    }
}
