package com.hydra.water

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object ReminderScheduler {
    private const val REQUEST = 9001

    fun scheduleNext(context: Context) {
        val now = LocalDateTime.now()
        val startMin = HydraPrefs.start(context)
        val endMin = HydraPrefs.end(context)
        val interval = HydraPrefs.interval(context).coerceAtLeast(15)

        val start = LocalTime.of(startMin / 60, startMin % 60)
        val end = LocalTime.of(endMin / 60, endMin % 60)
        val candidate = if (now.toLocalTime().isBefore(start)) {
            now.toLocalDate().atTime(start)
        } else if (now.toLocalTime().isAfter(end) || now.toLocalTime() == end) {
            now.toLocalDate().plusDays(1).atTime(start)
        } else {
            val minutesSinceStart =
                java.time.Duration.between(start, now.toLocalTime()).toMinutes()
            val nextStep = ((minutesSinceStart / interval) + 1) * interval
            val candidateTime = start.plusMinutes(nextStep)
            if (candidateTime.isAfter(end)) {
                now.toLocalDate().plusDays(1).atTime(start)
            } else {
                now.toLocalDate().atTime(candidateTime)
            }
        }

        val trigger = candidate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(context)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    fun cancel(context: Context) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context))
    }

    private fun pendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQUEST,
            Intent(context, HydrationAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
