package com.hydra.water

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.time.LocalTime

class MainActivity : ComponentActivity() {
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        NotificationHelper.createChannel(this)

        progress = findViewById(R.id.progress)
        tvProgress = findViewById(R.id.tvProgress)
        tvStatus = findViewById(R.id.tvStatus)

        val goalInput = findViewById<EditText>(R.id.goalInput)
        val startInput = findViewById<EditText>(R.id.startInput)
        val endInput = findViewById<EditText>(R.id.endInput)
        val intervalInput = findViewById<EditText>(R.id.intervalInput)

        findViewById<Button>(R.id.btn200).setOnClickListener { addWater(200) }
        findViewById<Button>(R.id.btn250).setOnClickListener { addWater(250) }
        findViewById<Button>(R.id.btn500).setOnClickListener { addWater(500) }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            HydraPrefs.reset(this)
            updateProgress()
        }

        findViewById<Button>(R.id.btnNotifications).setOnClickListener {
            requestNotificationPermission()
            openExactAlarmSettingsIfNeeded()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            try {
                val goal = goalInput.text.toString().toInt().coerceAtLeast(250)
                val start = parseTime(startInput.text.toString())
                val end = parseTime(endInput.text.toString())
                val interval = intervalInput.text.toString().toInt().coerceAtLeast(15)

                if (start >= end) {
                    Toast.makeText(this, "El inicio debe ser antes del fin.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                HydraPrefs.saveSettings(this, goal, start, end, interval)
                ReminderScheduler.scheduleNext(this)
                tvStatus.text = "Guardado. El próximo recordatorio se programará automáticamente."
                updateProgress()
            } catch (_: Exception) {
                Toast.makeText(this, "Revisa los datos.", Toast.LENGTH_SHORT).show()
            }
        }

        goalInput.setText(HydraPrefs.goal(this).toString())
        startInput.setText(formatTime(HydraPrefs.start(this)))
        endInput.setText(formatTime(HydraPrefs.end(this)))
        intervalInput.setText(HydraPrefs.interval(this).toString())
        updateProgress()
    }

    private fun addWater(ml: Int) {
        HydraPrefs.add(this, ml)
        updateProgress()
    }

    private fun updateProgress() {
        val amount = HydraPrefs.amount(this)
        val goal = HydraPrefs.goal(this).coerceAtLeast(1)
        progress.max = goal
        progress.progress = amount.coerceAtMost(goal)
        tvProgress.text = "$amount / $goal ml"
    }

    private fun parseTime(value: String): Int {
        val t = LocalTime.parse(value)
        return t.hour * 60 + t.minute
    }

    private fun formatTime(minutes: Int): String =
        "%02d:%02d".format(minutes / 60, minutes % 60)

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10
            )
        }
    }

    private fun openExactAlarmSettingsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val alarm = getSystemService(AlarmManager::class.java)
            if (!alarm.canScheduleExactAlarms()) {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                    tvStatus.text = "Puedes usar recordatorios sin precisión exacta; Android puede retrasarlos un poco."
                }
            }
        }
    }
}
