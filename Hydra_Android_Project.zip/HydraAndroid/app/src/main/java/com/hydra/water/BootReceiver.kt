package com.hydra.water

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED ||
            intent?.action == Intent.ACTION_TIME_SET ||
            intent?.action == Intent.ACTION_TIMEZONE_CHANGED) {
            NotificationHelper.createChannel(context)
            ReminderScheduler.scheduleNext(context)
        }
    }
}
